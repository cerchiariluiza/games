package com.loja.games.controller;

public class SwaggerConfig {

}
